import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JComponent;

public class TankShot extends JComponent {
	private final GameRuning tankGameInstance;
	private int xPos;
	private int yPos;
	private final int r = 6;
	private int xVelocity;
	private int yVelocity;
	private short angle;
	private static BufferedImage img;
	private Tank tankOne;
	private Rectangle rectangularBoundary;
	private int offset = 50;
	private int shoot_x = 0;
	private int shoot_y = 0;
	private int offsetx = 0;
	private int offsety = 0;
	private String player;
	/**
	 * Constructor for the shot fired by tank
	 * @param tre
	 * @param t
	 * @param img
	 * @param x
	 * @param y
	 * @param vx
	 * @param vy
	 * @param angle
	 */
	public TankShot(GameRuning tre, Tank t, BufferedImage img, int x, int y, int vx, int vy, short angle) {
		this.tankGameInstance = tre;
		this.tankOne = t;
		this.player = t.getPlayer();
		TankShot.img = img;
		this.xPos = x;
		this.yPos = y + 50;
		this.xVelocity = vx;
		this.yVelocity = vy;
		this.angle = angle;
		this.rectangularBoundary = new Rectangle(x, y, TankShot.img.getWidth(), TankShot.img.getHeight());
	}
	/**
	 * Setter for position along x axis
	 * @param x
	 */
	public void setX(int x) {
		this.xPos = x;
	}
	/**
	 * Setter for position along y axis
	 * @param y
	 */
	public void setY(int y) {
		this.yPos = y;
	}
	
	/**
	 * Setter for speed along x axis
	 * @param vx
	 */
	public void setVx(int vx) {
		this.xVelocity = vx;
	}
	
	/**
	 * Setter for speed along y axis
	 * @param vy
	 */
	public void setVy(int vy) {
		this.yVelocity = vy;
	}
	/**
	 * Setter for angle along x axis
	 * @param angle
	 */
	public void setAngle(short angle) {
		this.angle = angle;
	}
	
	/**
	 * Setter for image which is to be used to represent a shot
	 * @param img
	 */
	public void setImage(BufferedImage img) {
		TankShot.img = img;
	}
	/**
	 * Getter for position along x axis
	 */
	public int getX() {
		return this.xPos;
	}
	/**
	 * Getter for position along y axis
	 */
	public int getY() {
		return this.yPos;
	}

	/**
	 * Update the game based on the shot
	 */
	public void update() {
		this.moveForwards();
		//If collides with tank one
		if (this.CollidesWithTank(this.tankGameInstance.tankOne)) {
			if (this.tankGameInstance.tankOne.getPlayer() != this.player) {
				System.out.println(" Tank 1 Hit");
				this.tankGameInstance.tankOne.setHealth(this.tankGameInstance.tankOne.getHealth() - 16);
				this.tankGameInstance.shotsFired.remove(this);
			}
		}
		
		//collision with tank two
		if (this.CollidesWithTank(this.tankGameInstance.tankTwo)) {
			if (this.tankGameInstance.tankTwo.getPlayer() != this.player) {
				System.out.println("Tank 2 Hit");
				this.tankGameInstance.tankTwo.setHealth(this.tankGameInstance.tankTwo.getHealth() - 16);
				this.tankGameInstance.shotsFired.remove(this);
			}
		}

	}

	/**
	 * Moves the tank shot with the given celocity in one unit time
	 */
	private void moveForwards() {
		xVelocity = (int) Math.round(r * Math.cos(Math.toRadians(angle)));
		yVelocity = (int) Math.round(r * Math.sin(Math.toRadians(angle)));
		xPos += xVelocity;
		yPos += yVelocity;
		// checkBorder();
		this.rectangularBoundary.setLocation(xPos, yPos);
	}
	
	/**
	 * Update the GUI panel
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		AffineTransform rotation = AffineTransform.getTranslateInstance(this.xPos, this.yPos);
		rotation.rotate(Math.toRadians(angle), this.tankOne.getX() + (img.getWidth() / 2),
				this.tankOne.getY() + (img.getHeight() / 2));
		Graphics2D graphic2D = (Graphics2D) g;
		graphic2D.drawImage(img, rotation, null);

	}

	/**
	 * Getter for rectangular bounds of tank shot
	 */
	public Rectangle getBounds() {
		return this.rectangularBoundary;
	}
	
	/**
	 * Checks the validity of borders of tank shot
	 * @return
	 */
	public boolean checkBorder() {
		if (this.xPos < 0 || this.xPos >= 740 || this.yPos < 0 || this.yPos >= 720) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Returns a string equivalent of tank shot
	 * @return
	 */
	public String toSring() {
		return "Bullet: x=" + xPos + ", y=" + yPos + ", angle=" + angle;
	}
	
	/**
	 * add
	 * @param g
	 */
	public void drawImage(Graphics g) {

		AffineTransform rotation = AffineTransform.getTranslateInstance(xPos + offset, yPos);
		rotation.rotate(Math.toRadians(angle), img.getWidth() / 2, img.getHeight() / 2);
		Graphics2D graphic2D = (Graphics2D) g;
		graphic2D.drawImage(img, rotation, null);

	}
	
	/**
	 * 
	 * @param t1
	 * @return
	 */
	public boolean CollidesWithTank(Tank t1) {
		if (this.rectangularBoundary.intersects(t1.getBounds())) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 *  the distance travelled by tank shot in x direction
	 * @return
	 */
	public int getShoot_x() {
		return shoot_x;
	}

	/**
	 * 
	 * @param shoot_x
	 */
	public void setShoot_x(int shoot_x) {
		this.shoot_x = shoot_x;
	}
	/**
	 * the distance travelled by tank shot in y direction
	 * @return
	 */
	public int getShoot_y() {
		return shoot_y;
	}
	/**
	 * 
	 * @param shoot_y
	 */
	public void setShoot_y(int shoot_y) {
		this.shoot_y = shoot_y;
	}

	/**
	 * 
	 * @return
	 */
	public int getOffsetx() {
		return offsetx;
	}

	public void setOffsetx(int offsetx) {
		this.offsetx = offsetx;
	}

	public int getOffsety() {
		return offsety;
	}

	public void setOffsety(int offsety) {
		this.offsety = offsety;
	}
}
