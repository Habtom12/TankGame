import java.awt.Graphics;

import java.awt.image.BufferedImage;

import javax.swing.JComponent;

public class Explosion extends JComponent{
	private final GameRuning tankGameInstance;
	private static BufferedImage image;
	private int xCoor = 0;
	private int yCoor = 0;
	
	/**
	 * Constructor of the Explosion class
	 * @param tre
	 * @param img
	 */
	public Explosion(GameRuning tre, BufferedImage img) {
		this.tankGameInstance = tre;
		Explosion.image = img;
	}
	
	/**
	 * Sets the position of the explosion
	 * @param x
	 * @param y
	 */
	public void setXY( int x, int y) {
		this.xCoor = x;
		this.yCoor = y;
	}
	
	/**
	 * Draws the explosion on the panel 
	 * @param g
	 */
	public void drawImage(Graphics g) {
		g.drawImage(image, this.xCoor, this.yCoor, Explosion.image.getWidth(), Explosion.image.getHeight(), null);
	}

	/**
	 * Return the instance of GameRuning
	 * @return
	 */
	public GameRuning getTRE() {
		return tankGameInstance;
	}
}
